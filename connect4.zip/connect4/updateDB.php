<?php
    include("connection.php");

    session_start();
    if (isset($_POST['Array'])){
        $a =$_POST['Array'];
        $a =json_decode($a);
    }
    
    $username=$a[0];
    $time = $a[1];
    $win =$a[2];
    $loss = ($win == -1) ? 1:0;
    $win = ($a[2] == 1) ? 1:0;
    $total =1;

    $q = "select * from players where username ='$username' LIMIT 1";
    $output = mysqli_query($conn,$q);

    if($output){
        if(mysqli_num_rows($output)>0){
            $data= mysqli_fetch_assoc($output);
            $time += $data['time'];
            $win +=$data['wins'];
            $loss+= $data['loses'];
            $total +=$data['total'];
        }
    }

    $q = "update players set time='$time.' where username='$username'";
    mysqli_query($conn,$q);

    $q = "update players set wins='$win.' where username='$username'";
    mysqli_query($conn,$q);

    $q = "update players set loses='$loss.' where username='$username'";
    mysqli_query($conn,$q);

    $q = "update players set total='$total.' where username='$username'";
    mysqli_query($conn,$q);
?>