
<?php
    include("connection.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href = "menubar.css">
    <title>Leaderboard</title>
    <style>
        .Contact{
            height: 100%;
            width: 100%;
            position: fixed; /* It will stay in place*/
            z-index: 1; /* Stays in front of the page */
            bottom: 0;/* Stays at the bottom */
            background-color: #13284c;
            overflow-x: hidden; /* Disables the  scrolling*/
            transition: 0.5s; /*Shows the sliding effect*/
            font-family: 'Courier New', Courier, monospace;
            text-align: center;
        }

        .Contact p{
            padding: 8px 8px 8px 32px;
            color: whitesmoke;
            display: block;
            transition: 0.0s;
            font-size: 50px;
        }

        .c {
            margin-top:0px;
            padding: 50px;
            padding-bottom: 50px;
            background-color: #b1102b;
        }

        .closeContactButton {
            position: absolute; /* The x button should not move*/
            top: -20px; /* This will be at the top of the page */
            right: 15px; /* Moved 25 px from the right*/
            font-size: 90px; /* Making it visible */
            margin-top: 0;
            background-color: #b1102b;
            border: 0;
            color: whitesmoke;
        }
        .closeContactButton:hover{
            cursor: pointer;
        }
        .name{
            font-size: 60px;
        }
        .myt, th, td{
            color: whitesmoke;
            text-align: center;
            font-size: 40px;
            margin-left: auto;
            margin-right: auto;
            border: 1px solid whitesmoke;
            padding: 15px;
        }
        
    </style>
</head>
<body>
    
    <div id = "Contact" class = "Contact">
        <a href="index.html"><button class="closeContactButton">&times</button></a>
        <p style="font-size: 60px;" class="c">Leaderboard</p>

        <table class="myt">
            <th>User</th>
            <th>Wins</th>
            <th>Loses</th>
            <th>Total</th>
            <th>Time (seconds)</th>

            <?php
                $q= "select * from players";
                $output=mysqli_query($conn,$q);

                if($output){
                    if(mysqli_num_rows($output)>0){
                        while($row = mysqli_fetch_assoc($output)){
                            echo "<tr><td>" . $row["username"] ."</td><td>" .$row["wins"] ."</td><td>" .$row["loses"]."</td><td>".$row["total"]."</td><td>".$row["time"]."</td></tr>";
                        }
                       
                    }
                }
            ?>
        </table>
    </div>
    <div class="area"></div><nav class="main-menu">
        <ul>
            <li>
                <a href="index.html">
                    <i class="fa fa-home fa-2x"></i>
                    <span class="nav-text">
                        <button class="btn"></button>
                        Home 
                    </span>
                </a>
            </li>
            <li>
                <a href="help.html">
                    <!--button onclick="openInfo()"></button-->
                    <i class="fa fa-info fa-2x"></i>
                    <span class="nav-text">
                        <button class="btn" onclick="openInfo()"></button>
                        Help page
                    </span>
                </a>
              
            </li>
            <li class="has-subnav">
                <a href="contact.html">
                    <i class="fa fa-laptop fa-2x"></i>
                    <span class="nav-text">
                        <button class="btn" onclick="openContact()"></button>
                        Contact
                    </span>
                </a>
                
            </li>
            <li class="has-subnav">
                <a href="about.html">
                   <i class="fa fa-font fa-2x"></i>
                    <span class="nav-text">
                        <button class="btn" onclick="openAbout()"></button>
                        About
                    </span>
                </a>
                
            </li>
            <li class="has-subnav">
                <a href="leaderboard.php">
                   <i class="fa fa-bar-chart-o fa-2x"></i>
                    <span class="nav-text">
                        <button class="btn" onclick="openLeaderBoard()"></button>
                        Leaderboard
                    </span>
                </a>
               
            </li>
            <li>
                <a href="game.html">
                    <i class="fa fa-list fa-2x"></i>
                    <span class="nav-text">
                       <button class="btn"></button>
                       Game
                    </span>
                </a>
            </li>
            
        </ul>

        <ul class="logout">
            <li>
               <a href="login.html">
                     <i class="fa fa-power-off fa-2x"></i>
                    <span class="nav-text">
                        Logout
                    </span>
                </a>
            </li>  
        </ul>
    </nav>
    <script src = "connect4.js"></script>
    

</body>
</html>