<?php
session_start();

    include("connection.php");


    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if (!empty($username) && !empty($password)) {

            $query = "SELECT * FROM players WHERE username = '$username' LIMIT 1";

            $result = mysqli_query($conn, $query);

            if ($result) {
                if (mysqli_num_rows($result) > 0) {
                    echo '<script>alert("Username already exists!")</script>';
                }
                else {
                    $query = "INSERT INTO players (username,password) VALUES ('$username','$password')";

                    mysqli_query($conn, $query);

                    header("Location: login.html");
                    die;
                }
            }
        }
        else {
            echo '<script>alert("Please enter a username and a password")</script>';
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <style>
        html{
            height: 100%;
        }
        body {
            background-color:#13284c;
        }
        a{
            color: #b1102b;
        }
        a:hover{
            text-decoration: none;
        }
        .form {
            max-width: calc(100vw - 40px);
            width: 420px;
            height: auto;
            background: rgba(255, 255, 255, 1);
            padding: 30px;
            box-sizing: border-box;
            position: relative;
            background-size: cover;
            background-repeat: no-repeat;
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
        }
        .form:before{
            content: "";
            background-color: rgba(255, 255, 255, 0.9);
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            z-index: 0;
        }
        .form h2 {
            margin: 0;
            padding-bottom: 10px;
            color: #13284c;
            font-size: 22px;
            border-bottom: 3px solid #13284c;
            font-weight: 600;
            margin-bottom: 40px;
            text-align: center;
        }
        label{
            text-transform: uppercase;
            font-weight: 700;
        }
        input {
            width: 60%;
            padding: 10px;
            box-sizing: border-box;
            background: none;
            outline: none;
            resize: none;
            border: 0;
            font-family: 'Montserrat', sans-serif;
            border: 2px solid #13284c;
        }
        .form p:before {
            content: attr(type);
            display: block;
            margin: 10px 0 0;
            font-size: 13px;
            color: #5a5a5a;
            float: left;
            width: 40%;
        }
        button {
            padding: 8px 12px;
            margin: 4px 0;
            font-family: 'Montserrat', sans-serif;
            border: 2px solid #13284c;
            background: 0;
            color: #13284c;
            cursor: pointer;
            transition: all .3s;
        }
        button:hover {
            background: #13284c;
            color: #fff;
            border-color: #13284c;
            box-shadow: 0px 0 5px 0 #646171;
        }
        .login-btn{margin-top: 50px;}

        .relative{
            position: relative;
        }
        .relative i.fa{
            position: absolute;
            top: 10px;
            left: 0;
            width: 30px;
            color: #13284c;
            text-align: center;
            border-radius: 0 4px 4px 0;
            transition: all 0.15s ease-in-out;
        }
        input:focus + .fa{
            color: #13284c;
            transform: rotate(360deg);
        }
        .form-group{
            margin-bottom: 20px;
        }
        .form-control{
            font-size: 14px;
            padding-left: 40px;
            border: none;
            border-bottom: 1px solid #13284c;
            border-radius: 0;
            background-color: transparent;
        }
        .form-control:focus{
            border-color: #13284c;
            box-shadow: inset 0 0px 0px rgba(0,0,0,.075), 0 3px 4px -3px rgb(30, 102, 195);
            background-color: transparent;
        }
        .sign-up{
            margin-top: 30px;
            text-align: center;
            position: relative;
            margin-bottom: -15px;
        }
        .login-text{
            position: absolute;
            top: -11px;
            text-align: center;
            width: 30%;
            background-color: #fff;
            left: 50%;
            transform: translateX(-50%);
        }
        hr{
            margin-top: 1.25rem;
            margin-bottom: 1.25rem;
            border-top: 1px solid #b1102b;
        }
        /* --- Animated Buttons --- */
        .movebtn{
            background-color: transparent;
            display:inline-block;
            width:100%;
            background-image: none;
            padding: 8px 10px;
            border-radius: 0;
            -webkit-transition: all 0.5s;
            -moz-transition: all 0.5s;
            transition: all 0.5s;
            -webkit-transition-timing-function: cubic-bezier(0.5, 1.65, 0.37, 0.66);
            transition-timing-function: cubic-bezier(0.5, 1.65, 0.37, 0.66);
        }
        .movebtnre {
            border: 2px solid #ff5501;
            box-shadow: inset 0 0 0 0 #ff5501;
            color:#ff5501;
        }
        .movebtnsu {
            border: 2px solid #13284c;
            color: #ffffff;
            background-color: #13284c;
        }
    </style>
</head>
<body>
    <div class="form">
    
        <form class="form-horizontal signup"  method="post">
            <div class="form-wrap" style="position: relative;">
              <h2>Sign Up</h2>

              <div class="form-group">
                  <!-- <label for="email">Username:</label> -->
                  <div class="relative">
                      <input class="form-control" id="name" type="text" required="" autofocus="" title="" autocomplete="" placeholder="Username" name="username">
                      <i class="fa fa-user"></i>
                  </div>
              </div>
              
              <div class="form-group">
                  <!-- <label for="email">Password:</label> -->
                  <div class="relative">
                      <input id="myinput" class="form-control" type="password" required="" placeholder="Password" name="password">
                      <i class="fa fa-key"></i>
                  </div>
              </div> 
                              
              <div class="login-btn">
                <button class="movebtn movebtnsu" type="Submit">Submit <i class="fa fa-fw fa-paper-plane"></i></button>
              </div>
              
            </div>
            <div class="sign-up">
              <a href="login.html" class="signbtn"><small>Already member? Sign in <i>(Click me)</i></small></a>
          </div>
        </form>
    </div>
</body>
</html>