<?php
session_start();

    include("connection.php");
    


    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if (!empty($username) && !empty($password)) {

            $query = "SELECT * FROM players WHERE username = '$username' LIMIT 1";

            $result = mysqli_query($conn, $query);

            if ($result) {
                if (mysqli_num_rows($result) > 0) {
                    $userdata = mysqli_fetch_assoc($result);

                    if ($userdata['password'] === $password) {
                        $_SESSION['username'] = $userdata['username'];
                        header("Location: index.html");
                        die;
                    }

                }
            }
            header("Location: login.html");
            die;
        }
        else {
            header("Location: login.html");
            die;
        }
    }
?>