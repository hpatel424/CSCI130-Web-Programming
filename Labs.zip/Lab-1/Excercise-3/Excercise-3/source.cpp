
#include<iostream>
#include <string>
#include <fstream>
#include<vector>
#include <stdio.h>
#include <stdlib.h>
#include<time.h>


using namespace std;

string MatrixToHTMLpage(double** M);

const int rows = 4;
const int col = 2;

int main() {
    srand(time(NULL));
    fstream file;
    file.open("e3.html", ios::out);

    if (!file) {
        cout << "Error opening the file." << endl;
        return 0;
    }
    cout << "File opened successsfully." << endl;
    
    double** M;
    M = new double* [rows];
    for (int i = 0; i < rows; i++) {
        M[i] = new double[col];
        for (int j = 0; j < col; j++) {
            int num = (rand() % 11) + 1;
            M[i][j] = num;
        }
    }
    file << MatrixToHTMLpage(M);
    file.close();

    return 0;
}

string MatrixToHTMLpage(double** M) {
    string doc;
    doc = "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<title>CSci 130-Lab 1</title>\n</head>\n<body>\n<table>";
    doc += "\n<caption>Numbers</caption>";
    double avg = 0;
    double coladd = 0;

    for (int i = 0; i < rows; i++) {
        doc = doc + "\n<tr>";
        for (int j = 0; j < col; j++) {
            doc = doc + "\n<td>" + to_string(M[i][j]) + "</td>";
        }
        doc = doc + "\n</tr>";
    }
    doc = doc + "\n<tr>";
    for (int i = 0; i < col; i++) {
        for (int j = 0; j < rows; j++) {
            coladd += M[j][i];
        }
        avg = coladd / rows;
        doc = doc + "\n\<td><strong>" + to_string(avg) + "</strong></td>";
        coladd = 0;
    }
    doc = doc + "\n</tr>\n</table>\n</body>\n</html>";
    return doc;
}