
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `car` (
  `id` int(6) NOT NULL,
  `make` varchar(30) NOT NULL,
  `model` varchar(30) NOT NULL,
  `year` int(4) NOT NULL,
  `color` varchar(30) NOT NULL,
  `bodytype` varchar(30) NOT NULL,
  `transmission` varchar(30) NOT NULL,
  `drivetype` varchar(30) NOT NULL,
  `imgDir` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



INSERT INTO `car` (`id`, `make`, `model`, `year`, `color`, `bodytype`, `transmission`, `drivetype`, `imgDir`) VALUES
(1, 'Lamborghini', 'STO', 2015, 'Red', 'Coupe', 'Automatic', 'AWD', 'cars/1.jpg'),
(2, 'Maserati', 'Ghibli', 2022, 'Orange', 'sport', 'Manual', 'AWD', 'cars/2.jpg'),
(3, 'Lamborghini', 'EVO', 2023, 'Orange', 'convertible', 'Automatic', 'FWD', 'cars/3.jpg'),
(4, 'Aston Martin', 'Aventador', 1111, 'Gold', 'SUV', 'Manual', 'RWD', 'cars/4.jpg'),
(5, 'Porsche', '911', 2020, 'Blue', 'sport', 'Manual', 'AWD', 'cars/5.jpg'),
(6, 'Audi', 'A110', 2026, 'Black', 'hatch', 'Automatic', 'FWD', 'cars/6.jpg'),
(7, 'Ferrari', '100G', 2019, 'Yellow', 'Truck', 'Automatic', 'AWD', 'cars/7.jpg'),
(8, 'Mercedes', 'G Wagon', 2021, 'White', 'SUV', 'Manual', 'RWD', 'cars/8.jpg');

ALTER TABLE `car`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);


ALTER TABLE `car`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;