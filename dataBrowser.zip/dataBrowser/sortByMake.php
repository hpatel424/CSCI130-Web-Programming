<?php
include "connection.php";

    $sql='SELECT * FROM car';
    $r = mysqli_query($conn, $sql);
    $noOfItem = 1; 
    $sql='SELECT * FROM car'; 
    $r = mysqli_query($conn, $sql);
    $noOfResult = mysqli_num_rows($r);

    $pg = ceil($noOfResult/$noOfItem);

    if (!isset($_GET['page'])) {
        $totalPg = 1;
    } 
    else {
        $totalPg = $_GET['page'];
    }

    $firstResult = ($totalPg-1)*$noOfItem;

    $sql='SELECT * FROM car ORDER BY make ASC LIMIT ' . $firstResult . ',' .  $noOfItem;
    $r = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Main Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
    <style>
        @import url('https://fonts.googleapis.com/css?family=Poppins');


        td, tr {
            vertical-align: middle;
            text-align: center;
            font-size: 15pt;
        }

        body {
            font-family:'Courier New', Courier, monospace;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        img {

            height: 300px;
        }
        th{
            width: auto;
            font-size: 20pt;
            
        }
        .container{
            background-color: #13284c;
            color: white;
            text-align: center;
        }
        h1{
            background-color: #b1102b;
            padding: 20px;
            text-align: center;
        }
        a{
            color: black;
            font-size: 20pt;
        }
        input,select{
            font-size: 20pt;
            font-family: 'Courier New', Courier, monospace;
        }
        label{
            font-size: 20pt;
        }
        h3{
            background-color: #b1102b;
            padding: 30px;
            text-align: center;
            color: white;
            font-size: 40pt;
        }
        body{
            margin: 0px;
            background-color: #13284c;
        }
        a{
            color: white;
        }
        .close{
            text-align: right;
            font-size: 65pt;
            color: black;
            font-family: Arial, Helvetica, sans-serif;
            margin-top: -5px;
        }
        .close:hover{
            color:white;
        }
        a{
            color: white;
        }
        a:hover{
            color:white
        }


        .switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 34px;
        }

        .switch input { 
        opacity: 0;
        width: 0;
        height: 0;
        }

        .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        -webkit-transition: .4s;
        transition: .4s;
        }

        .slider:before {
        position: absolute;
        content: "";
        height: 26px;
        width: 26px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        -webkit-transition: .4s;
        transition: .4s;
        }

        input:checked + .slider {
        background-color: #2196F3;
        }

        input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
        }

        input:checked + .slider:before {
        -webkit-transform: translateX(26px);
        -ms-transform: translateX(26px);
        transform: translateX(26px);
        }

        /* Rounded sliders */
        .slider.round {
        border-radius: 34px;
        }

        .slider.round:before {
        border-radius: 50%;
        }
        .edit:hover{
            text-decoration: none;
        }

    </style>
</head>
<body>
    <h3>Sort By Make <a class="close" href="index.php"><button class="close">&times</button></a><br></h3>

    <button class="btn btn-outline-success"><a href="addCar.php"> Add Car</a></button><br><br>
                
    <div class="container-fluid">
        <table class="table table-hover table-dark">
            <thead>
                <tr>
                    <th> ID </th>
                    <th>Make</th>
                    <th>Model</th>
                    <th>Year</th>
                    <th>Color</th>
                    <th>Body Type</th>
                    <th>Transmission</th>
                    <th>Drive Type</th>
                    <th>Change?</th>
                 </tr>
            </thead>
            <?php
            while($row = mysqli_fetch_array($r)) {
                echo 
                '<tr>
                <td>' . $row["id"] . '</td>
                <td>' . $row["make"] . '</td>
                <td> ' . $row["model"] . '</td>
                <td> ' . $row["year"] . '</td>
                <td> ' . $row["color"] . '</td>
                <td> ' . $row["bodytype"] . '</td>
                <td> ' . $row["transmission"] . '</td>
                <td> ' . $row["drivetype"] . '</td>
                <td>
                
                <label class="switch">
                <input type="checkbox" onclick="update()">
                <span class="slider round"></span>
                </label>

                <button id ="updatebtn" class="btn btn-outline-primary"><a class="edit" style="color:white" href="editCar.php?id='.$row['id'].'">Edit</a></button>
                <button class="btn btn-outline-danger"><a style="color:white" href="deleteCar.php?id='.$row['id'].'">Delete</a></button>
                <td>
                </tr>
                
                <tr> 
                <td colspan="9" width="250px" height="250px">' . '<img src="'.$row['imgDir'].'" max-width="100%" max-height="100%">' . '</td> 
                </tr>';
            }
            ?>
        </table>
	

     <nav>
            <ul class="pagination justify-content-center">
                <?php
                echo "<li class='page-item'><center><a href='sortByMake.php?page=1' ><button style='margin:5px' class='btn btn-outline-light'>First</button></a></li>";
                ?>

                <?php
                    if ($totalPg > 1) {
                        echo "<li><a href='sortByMake.php?page=".($totalPg-1)."' ><button style='margin:5px' class='btn btn-outline-light'>Previous</button></a></li>";
                    }
                    else {
                        echo "<li><a href='' ><button type'button' style='margin:5px' class='btn btn-outline-light' disabled>Previous</button></a></li>";
                    }
                ?>
                
                <?php
                    if ($totalPg < $pg) {
                        echo "<li><a href='sortByMake.php?page=".($totalPg+1)."'><button style='margin:5px' class='btn btn-outline-light'>Next</button></a></li>";
                    }
                    else {
                        echo "<li><a href='' ><button type'button' style='margin:5px' class='btn btn-outline-light' disabled >Next</button></a></li>";
                    }
                ?>

                <?php
                echo "<li><a href='sortByMake.php?page=".$pg."'><buttonstyle='margin:5px' class='btn btn-outline-light'>Last</button></a></li>";
                ?>
            </ul>
        </nav>
    </div>
    </table>
    <script>
        function update() {
            document.getElementById("updatebtn").disabled = (document.getElementById("updatebtn").disabled == true) ? false : true;
    }</script>
</body>
</html>