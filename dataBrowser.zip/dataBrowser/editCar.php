<?php
include "connection.php";


        if (isset($_GET['id'])) {

            $uid = $_GET['id'];
	
    $sql = "SELECT * FROM `car` WHERE `id` = '$uid'";
   $r = $conn->query($sql);

if ($r->num_rows > 0) {
		 while($row = $r->fetch_assoc()) {
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1, shirnk-to-fit=no">
    <!--link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"-->
    <title>Update car</title>
    <style>
         .container{
            background-color: #13284c;
            color: white;
            text-align: center;
        }
        h1{
            background-color: #b1102b;
            padding: 20px;
            text-align: center;
        }
        a{
            color: white;
            font-size: 20pt;
        }
        input,select{
            font-size: 20pt;
            font-family: 'Courier New', Courier, monospace;
        }
        label{
            font-size: 20pt;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Edit Car</h1>
	
        <form action="" method="post" enctype="multipart/form-data">
            <div>
                <label>Make: </label>
                <input type="text" name="make" value="<?php echo $row['make'] ?>">
            </div>
            <br>
            <div>
                <label>Model: </label>
                <input type="text" name="model" value="<?php echo $row['model'] ?>" >
            </div>
            <br>
            <div>
                <label>Year: </label>
                <input type="year" name="year" value="<?php echo $row["year"] ?>">
            </div>
            <br>
            <div>
                <label>Color: </label>
                <input type="color" name="color" value="<?php echo $row["color"] ?>">
            </div>
            <br>
            <div>
                <label>Body Style:  </label>
                <select name="bodytype" id="body" value="<?php echo $row["bodytype"] ?>">
                <option value="sedan">Sedan</option>
                <option value="coupe">Coupe</option>
                <option value="sport">Sport Car</option>
                <option value="hatch">Hatchback</option>
                <option value="convertible">Convertible</option>
                <option value="SUV">SUV</option>
                <option value="minivan">Minivan</option>
                <option value="truck">Truck</option>
                </select><br>
            </div>
            <br>
            <div>
                <label>Transmission: </label><br>

                <?php if ($row["transmission"] === "Automatic" ){?>
                    
                    <input type="radio" id="Automatic" name="transmission" value="Automatic" checked>
                    <label for="Automatic">Automatic</label><br>

                    <input type="radio" id="Manual" name="transmission" value="Manual">
                    <label for="Manual">Manual</label><br>

                <?php } else {?>
                    <input type="radio" id="Automatic" name="transmission" value="Automatic">
                    <label for="Automatic">Automatic</label><br>

                    <input type="radio" id="Manual" name="transmission" value="Manual">
                    <label for="Manual">Manual</label><br>
                <?php }?>
            </div>
            <br>
            <div>
                <label>Drive Type: </label><br>
				<?php if ($row["drivetype"] === "AWD" ){?>
	
                    <input type="radio" id="AWD" name="drivetype" value="AWD" checked>
                    <label for="AWD">AWD</label><br>
                
                    <input type="radio" id="FWD" name="drivetype" value="FWD">
                    <label for="FWD">FWD</label><br>

                    <input type="radio" id="RWD" name="drivetype" value="RWD">
                    <label for="RWD">RWD</label><br>
				<?php } else if($row["drivetype"] === "FWD") {?>

                    <input type="radio" id="AWD" name="drivetype" value="AWD">
                    <label for="AWD">AWD</label><br>
            
                    <input type="radio" id="FWD" name="drivetype" value="FWD" checked>
                    <label for="FWD">FWD</label><br>
                    
                    <input type="radio" id="RWD" name="drivetype" value="RWD">
                    <label for="RWD">RWD</label><br>
				<?php } else {?>
                    <input type="radio" id="AWD" name="drivetype" value="AWD">
                    <label for="AWD">AWD</label><br>
            
                    <input type="radio" id="FWD" name="drivetype" value="FWD">
                    <label for="FWD">FWD</label><br>
                    
                    <input type="radio" id="RWD" name="drivetype" value="RWD" checked>
                    <label for="RWD">RWD</label><br>
                    <?php }?>

            </div>
            <br>
            <div>
            <label for="image">Car Photo: </label><br>
			
			<img src="<?php echo $row["imgDir"] ?>" width="350" height="250">
	
            </div>
            <br>
			<div>
                <label for="image">Change Car Image: </label>
                <input type="file" name="image" id="image">
                <input type="submit" name="update" value="Change">      
	        </div>	
            <br>
            <input type="submit" name="submit"value="Submit">
            <a href="index.php">Cancel</a>
        </form>
    </div>

<form action="" method="post" enctype="multipart/form-data">
	
	 
</form>

<?php 
if(isset($_POST['update'])){

        $imgDir = "cars/";
        
        $imgFile = $imgDir . basename($_FILES["image"]["name"]);        
        if (!file_exists($_FILES["image"]["tmp_name"])) {
        } else {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $imgFile)) {

		$sql = "UPDATE car SET imgDir = '$imgFile' WHERE id = $uid";
if ($conn->query($sql) === TRUE) {


}
	echo '<script>
        alert("Image Updated Successfully");
		window.location = "index.php";
		
	</script>';
}}}
?>
		
		<?php
		
		if(isset($_POST['submit'])){
			$filepath = $row["imgDir"];
			$originalimage = isset($_POST[$filepath]);
		$sql = "UPDATE car SET make = '".$_POST['make']."',model = '".$_POST['model']."',year = '".$_POST['year']."',color = '".$_POST['color']."',bodytype = '".$_POST['bodytype']."',transmission = '".$_POST['transmission']."',drivetype = '".$_POST['drivetype']."' WHERE id = $uid";
if ($conn->query($sql) === TRUE) {


}
	echo '<script>
        alert("Updated Successfully");
		window.location = "index.php";
		
	</script>';}	 
}
}	}?>
		

</body>
</html>
