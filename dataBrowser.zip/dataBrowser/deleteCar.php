<?php
   include "connection.php";

    if (isset($_GET['id'])) {
        $uid = $_GET['id'];
        $sql = "DELETE FROM `car` WHERE `id`='$uid'";
        $result = $conn->query($sql);
        if ($result == TRUE) {
            echo "Record deleted successfully.";
        }
        else {
            echo "Error:" . $sql . "<br>" . $conn->error;
        }
        echo '<script>
        alert("Successfully Deleted");
		window.location = "index.php";
	</script>';
    
    } 
?>