<?php
include "connection.php";

if (isset($_POST['submit'])) {
	$make=$_POST['make'];
    $model=$_POST['model'];
    $year=$_POST['year'];
    $color=$_POST['color'];
    $bodytype=$_POST['bodytype'];
    $transmission=$_POST['transmission'];
    $drivetype=$_POST['drivetype'];
	
        $imgDir = "cars/";
        $imgFile = $imgDir . basename($_FILES["image"]["name"]);        
        if (!file_exists($_FILES["image"]["tmp_name"])) {
        } else {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $imgFile)) {

	
    $sql="INSERT INTO car(make, model, year, color, bodytype, transmission, drivetype, imgDir)
    VALUES('$make','$model', '$year', '$color', '$bodytype', '$transmission', '$drivetype', '$imgFile')";
	
	
    $r=mysqli_query($conn, $sql);
	
	
    if($r == TRUE) {
        echo "Data inserted successfully";
    }
    else {
        echo "Error:". $sql . "<br>". $conn->error;
    }  
    
	}
		}
echo '<script>
		window.location = "index.php";
		
	</script>';}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add car</title>
    <style>
        @import url(https://fonts.googleapis.com/css?family=Montserrat:400,700);
        .container{
            background-color: #13284c;
            color: white;
            text-align: center;
        }
        h1{
            background-color: #b1102b;
            padding: 20px;
            text-align: center;
        }
        a{
            color: white;
            font-size: 20pt;
        }
        input,select{
            font-size: 20pt;
            font-family: 'Courier New', Courier, monospace;
        }
        label{
            font-size: 20pt;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Add Car</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <div>
                <label>Make: </label>
                <input type="text" name="make" placeholder="Make">
            </div>
            <br>
            <div>
                <label>Model: </label>
                <input type="text" name="model" placeholder="Model">
            </div>
            <br>
            <div>
                <label>Year: </label>
                <input type="text" name="year" placeholder="YYYY">
            </div>
            <br>
            <div>
                <label>Color: </label>
                <input type="color" name="color">
            </div>
            <br>
            <div>
                <label>Body Style: </label>
                <select name="bodytype" id="body">
                <option value="sedan">Sedan</option>
                <option value="coupe">Coupe</option>
                <option value="sport">Sport Car</option>
                <option value="hatch">Hatchback</option>
                <option value="convertible">Convertible</option>
                <option value="SUV">SUV</option>
                <option value="minivan">Minivan</option>
                <option value="truck">Truck</option>
                </select><br>
            </div>
            <br>
            <div>
                <label>Transmission: </label><br>
                <input type="radio" id="Automatic" name="transmission" value="Automatic" checked>
                <label for="Automatic"> Automatic</label><br>
                
                <input type="radio" id="Manaul" name="transmission" value="Manual">
                <label for="Manaul"> Manual</label><br><br>
                
            </div>
            <div>
                <label>Drive Type: </label><br>
                    <input type="radio" id="AWD" name="drivetype" value="AWD" checked>
                    <label for="AWD">AWD</label><br>
                    <input type="radio" id="FWD" name="drivetype" value="FWD">
                    <label for="FWD">FWD</label><br>
                    <input type="radio" id="FWD" name="drivetype" value="RWD">
                    <label for="RWD">RWD</label><br>
            </div>
            <br>
            <div>
            <label for="image">Upload Photo: </label>
            <input type="file" name="image" id="image">
            </div>
            <br>
            <input type="submit" name="submit" value="Submit">
            <a href="index.php" >Cancel</a>
        </form>
    </div>
</body>
</html>
